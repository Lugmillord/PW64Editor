namespace PW64Editor.Core.Text;

/// <summary>One element of the text markup, for the reference shown to users.</summary>
/// <param name="Syntax">How it is written, e.g. "[b]...[/b]".</param>
/// <param name="Meaning">What it does in the game.</param>
/// <param name="StoredAs">How it is stored in the ROM (16-bit codes).</param>
public sealed record TextMarkupElement(string Syntax, string Meaning, string StoredAs);

/// <summary>
/// Describes the markup produced by <see cref="TextCodec"/>, for help screens.
/// </summary>
public static class TextMarkup
{
    public static IReadOnlyList<TextMarkupElement> Elements { get; } =
    [
        new("[b]Text[/b]", "Shows the text in the bold variant of the font. Spaces inside stay regular spaces, as in the original game.", "glyph number + 0x60"),
        new("(line break)", "Starts a new line. Every text also ends with an invisible line break that the editor adds automatically.", "0x00FE"),
        new("[x=212]", "Continues the line at horizontal position 212. Used to line up columns, e.g. points in score sheets. The game writes numbers in front of these positions.", "0x00FD, 212, 0"),
        new("[x=212,y=5]", "Same, with a non-zero third value. Does not occur in the original game; the game ignores the value.", "0x00FD, 212, 5"),
        new("[#5C]", "A code with no character of its own (an unused or duplicate font glyph), kept exactly as it is. Any hex number can appear here. Does not occur in the original texts.", "the given number"),
        new("[nonl]", "Only at the very end: the text has no final line break. Does not occur in the original texts.", "final 0x00FE left out"),
    ];
}
