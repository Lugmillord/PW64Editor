using System.Windows;
using PW64Editor.Core.Text;

namespace PW64Editor.App.Views;

/// <summary>
/// Explains the codes in square brackets and lists the characters of the game's text font.
/// </summary>
public partial class TextCodesWindow : Window
{
    public TextCodesWindow(TextFont font)
    {
        InitializeComponent();
        CodeList.ItemsSource = TextMarkup.Elements;

        string regular = font.GetCharacters(bold: false);
        string bold = font.GetCharacters(bold: true);
        RegularChars.Text = Spaced(regular);
        BoldChars.Text = Spaced(bold);

        string onlyRegular = new(regular.Where(c => !bold.Contains(c)).ToArray());
        string onlyBold = new(bold.Where(c => !regular.Contains(c)).ToArray());
        DifferenceText.Text = (onlyRegular.Length, onlyBold.Length) switch
        {
            (0, 0) => "Both styles have the same characters.",
            _ => $"Only in regular: {(onlyRegular.Length > 0 ? Spaced(onlyRegular) : "none")}.   " +
                 $"Only in bold: {(onlyBold.Length > 0 ? Spaced(onlyBold) : "none")}.",
        };
    }

    /// <summary>Puts a space between characters, so each one is easy to see. The space itself is shown as "(space)".</summary>
    private static string Spaced(string characters) =>
        string.Join(" ", characters.Select(c => c == ' ' ? "(space)" : c.ToString()));

    private void OnClose(object sender, RoutedEventArgs e) => Close();
}
